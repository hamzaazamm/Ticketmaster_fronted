"use client";

import {
  FaFacebookF,
  FaTwitter,
  FaBlogger,
  FaYoutube,
  FaInstagram,
  FaApple,
  FaGooglePlay,
} from "react-icons/fa";


import Image from "next/image";
import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper/modules';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';



export default function Home() {
  return (
    <>
      <main className="min-h-screen bg-white font-sans">
        {/* Top black header */}
        <div className="bg-black text-white text-sm flex justify-between px-6 py-2">
          <div>🇺🇸 US</div>
          <div className="space-x-4">
            <span>Hotels</span>
            <span>Sell</span>
            <span>Gift Cards</span>
            <span>Help</span>
            <span>VIP</span>
            <span className="font-semibold">PayPal</span>
          </div>
        </div>

        {/* Main Navbar */}
        <nav className="bg-indigo-700 text-white py-4 px-6 flex justify-between items-center" aria-label="Main navigation">
          <div className="text-xl font-bold">ticketmaster</div>
          <div className="space-x-6 text-sm">
            <a href="#">Concerts</a>
            <a href="#">Sports</a>
            <a href="#">Arts, Theater & Comedy</a>
            <a href="#">Family</a>
          </div>
          <div className="text-sm cursor-pointer" role="button" tabIndex={0} aria-label="Sign In or Register">👤 Sign In/Register</div>
        </nav>

        {/* Search Section */}
        <section className="bg-indigo-700 py-6 flex justify-center" aria-label="Search events">
          <div className="w-[1000px] h-[52px] bg-white rounded-md flex items-center space-x-2 px-2">
            {/* Location Selector */}
            <div className="flex items-center bg-white text-black px-3 py-2 rounded-md border w-[180px] text-sm" role="region" aria-label="Location selector">
              <span className="mr-2" aria-hidden="true">📍</span>
              <span className="truncate">New York, NY</span>
            </div>

            {/* Date Selector */}
            <div className="flex items-center bg-white text-black px-6 py-2 rounded-md border w-[150px] text-sm" role="region" aria-label="Date selector">
              <span className="mr-2" aria-hidden="true">📅</span>
              <span className="truncate">All Dates</span>
              <span className="ml-auto" aria-hidden="true">▼</span>
            </div>
            {/* Search Input */}
            <input
              type="text"
              placeholder="Search by Artist, Event or Venue"
              className="flex-1 px-4 border text-sm text-black h-full"
              aria-label="Search by Artist, Event or Venue"
            />

            {/* Search Button */}
            <button
              className="bg-white text-indigo-700 border border-indigo-700 px-5 py-2 rounded-md font-medium text-sm hover:bg-indigo-50 h-full"
              aria-label="Search"
            >
              Search
            </button>
          </div>
        </section>

        {/* Hero Banner */}
      <div className="relative bg-gray-700 text-white h-96 flex flex-col justify-center px-10 bg-cover bg-center"
        style={{ backgroundImage: "url('/images/image1.jpg')" }}>
        <p className="text-xs uppercase">Promoted</p>
        <h1 className="text-3xl font-bold mb-2">Bryan Adams: Roll with the Punches</h1>
        <p className="mb-4">CITI PRESALE AVAILABLE NOW</p>
        <button className="bg-indigo-700 hover:bg-indigo-800 px-4 py-2 w-40 text-white rounded">
          Find Tickets
        </button>
        <div className="absolute right-10 bottom-10 text-3xl font-bold text-white opacity-40">citi</div>
      </div>





{/* Tickets On Sale Now Section */}
<section className="px-6 py-10 bg-white">
  <h2 className="text-2xl font-bold mb-6 text-center">Tickets On Sale Now</h2>
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
    {/* Card 1 */}
    <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300 relative group">
      <img
        src="/images/image1.jpg"
        alt="FIFA Club World Cup"
        className="w-full h-80 object-cover"
      />
      <div className="p-4">
        <span className="text-sm text-red-500 font-semibold">Promoted</span>
        <h3 className="font-semibold text-lg mt-2">
          FIFA Club World Cup
        </h3>
        <p className="text-sm text-gray-600 mt-2">
          Roll up in style as a VIP at this prestigious football event.
        </p>
        <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
          Discover More →
        </a>
      </div>
      {/* Right Arrow Icon */}
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 text-3xl text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        ➔
      </div>
    </div>

    {/* Card 2 */}
    <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300 relative group">
      <img
        src="/images/image3.jpg"
        alt="Wiz Khalifa"
        className="w-full h-80 object-cover"
      />
      <div className="p-4">
        <span className="text-sm text-red-500 font-semibold">Promoted</span>
        <h3 className="font-semibold text-lg mt-2">
          Wiz Khalifa
        </h3>
        <p className="text-sm text-gray-600 mt-2">
          Catch the famous rapper live in concert and enjoy an unforgettable show.
        </p>
        <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
          Discover More →
        </a>
      </div>
      {/* Right Arrow Icon */}
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 text-3xl text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        ➔
      </div>
    </div>

    {/* Card 3 */}
    <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300 relative group">
      <img
        src="/images/images4.jpg"
        alt="Dan Soder"
        className="w-full h-80 object-cover"
      />
      <div className="p-4">
        <span className="text-sm text-red-500 font-semibold">Promoted</span>
        <h3 className="font-semibold text-lg mt-2">
          Dan Soder
        </h3>
        <p className="text-sm text-gray-600 mt-2">
          Get ready for laughs with this popular comedian’s stand-up performance.
        </p>
        <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
          Discover More →
        </a>
      </div>
      {/* Right Arrow Icon */}
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 text-3xl text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        ➔
      </div>
    </div>

    {/* Card 4 */}
    <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300 relative group">
      <img
        src="/images/image3.jpg"
        alt="Awakening"
        className="w-full h-80 object-cover"
      />
      <div className="p-4">
        <span className="text-sm text-red-500 font-semibold">Promoted</span>
        <h3 className="font-semibold text-lg mt-2">
          Awakening
        </h3>
        <p className="text-sm text-gray-600 mt-2">
          Immerse yourself in this awe-inspiring live theater show.
        </p>
        <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
          Discover More →
        </a>
      </div>
      {/* Right Arrow Icon */}
      <div className="absolute top-1/2 right-4 transform -translate-y-1/2 text-3xl text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        ➔
      </div>
    </div>
  </div>
</section>




<div className="w-full px-4 py-10">
      <h2 className="text-2xl font-bold mb-6 text-center">Popular Near You</h2>

      <Swiper
        modules={[Navigation, Pagination]}
        spaceBetween={20}
        slidesPerView={3}
        navigation
        pagination={{ clickable: true }}
        breakpoints={{
          0: {
            slidesPerView: 1,
          },
          768: {
            slidesPerView: 3,
          },
        }}
      >
        <SwiperSlide>
          <img src="/images/images5.png" alt="Image 1" className="rounded-lg w-full h-64 object-cover" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="/images/images4.jpg" alt="Image 2" className="rounded-lg w-full h-64 object-cover" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="/images/image3.jpg" alt="Image 3" className="rounded-lg w-full h-64 object-cover" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="/images/image2.jpeg" alt="Image 4" className="rounded-lg w-full h-64 object-cover" />
        </SwiperSlide>
        <SwiperSlide>
          <img src="/images/image1.jpg" alt="Image 5" className="rounded-lg w-full h-64 object-cover" />
        </SwiperSlide>
      </Swiper>
    </div>

       

        {/* Discover More Section */}
        <section className="px-6 py-10 bg-white">
        <h2 className="text-2xl font-bold mb-6 text-center">Discover More</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Card 1 */}
            <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300">
              <img
                src="/images/image3.jpg"
                alt="Disney On Ice"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">Theater</p>
                <h3 className="font-semibold text-lg mb-2">
                  Disney On Ice Guide
                </h3>
                <p className="text-sm text-gray-600">
                  Here's what you need to know about how to make your Disney On Ice outing a dream come true.
                </p>
                <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
                  Discover More →
                </a>
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300">
              <img
                src="/images/images4.jpg"
                alt="Concert Tips"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">Music</p>
                <h3 className="font-semibold text-lg mb-2">
                  What to Bring to a Concert
                </h3>
                <p className="text-sm text-gray-600">
                  Read our ultimate packing checklist before you go to your next concert.
                </p>
                <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
                  Discover More →
                </a>
              </div>
            </div>

            {/* Card 3 */}
            <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300">
              <img
                src="/images/images5.png"
                alt="Ticketmaster Tips"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">Tips</p>
                <h3 className="font-semibold text-lg mb-2">
                  Get Started on Ticketmaster
                </h3>
                <p className="text-sm text-gray-600">
                  Everything you need to know about buying tickets, navigating your account, and more.
                </p>
                <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
                  Discover More →
                </a>
              </div>
            </div>

            {/* Card 4 */}
            <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300">
              <img
                src="/images/image3.jpg"
                alt="Broadway Shows"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">Arts & Theater</p>
                <h3 className="font-semibold text-lg mb-2">
                  9 Broadway Shows to See This Spring in NYC
                </h3>
                <p className="text-sm text-gray-600">
                  Need ideas for family activities in NYC? Here are the best Broadway shows to see during the 2025 spring season.
                </p>
                <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
                  Discover More →
                </a>
              </div>
            </div>

            {/* Card 5 */}
            <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300">
              <img
                src="/images/images4.jpg"
                alt="Ticket Sales Tips"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">Tips</p>
                <h3 className="font-semibold text-lg mb-2">
                  Don’t Play It By Ear — Prepare for Ticket Sales
                </h3>
                <p className="text-sm text-gray-600">
                  Tips to help you prepare for ticket sales and boost your chances to be there live.
                </p>
                <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
                  Discover More →
                </a>
              </div>
            </div>

            {/* Card 6 */}
            <div className="bg-gray-100 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300">
              <img
                src="/images/images5.png"
                alt="MLB Season"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">Sports</p>
                <h3 className="font-semibold text-lg mb-2">
                  MLB 2025 Season FAQs
                </h3>
                <p className="text-sm text-gray-600">
                  Get excited for Spring Training and Opening Day with our guide to the 2025 MLB season.
                </p>
                <a href="#" className="text-indigo-600 mt-3 inline-block font-medium text-sm hover:underline">
                  Discover More →
                </a>
              </div>
            </div>
          </div>
        </section>

        


        {/* Footer */}
        <footer className="bg-gray-900 text-gray-300 text-sm" aria-label="Footer">
          <div className="max-w-15xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
            <h2 className="text-2xl font-bold text-white flex-col">ticketmaster</h2>
              <h4 className="text-white font-bold mb-3">Let's connect</h4>
              <ul className="space-y-2">
                <li className="flex items-center space-x-2"><FaFacebookF /><a href="#">Facebook</a></li>
                <li className="flex items-center space-x-2"><FaTwitter /><a href="#">X</a></li>
                <li className="flex items-center space-x-2"><FaBlogger /><a href="#">Blog</a></li>
                <li className="flex items-center space-x-2"><FaYoutube /><a href="#">YouTube</a></li>
                <li className="flex items-center space-x-2"><FaInstagram /><a href="#">Instagram</a></li>
              </ul>

              <h4 className="text-white font-bold mt-6 mb-3">Download Our Apps</h4>
              <ul className="space-y-2">
                <li className="flex items-center space-x-2"><FaApple /><a href="#">App Store</a></li>
                <li className="flex items-center space-x-2"><FaGooglePlay /><a href="#">Google Play</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-3">Helpful Links</h4>
              <ul className="space-y-1">
                <li><a href="#">Help / FAQ</a></li>
                <li><a href="#">Sell</a></li>
                <li><a href="#">My Account</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Gift Cards</a></li>
                <li><a href="#">Refunds and Exchanges</a></li>
                <li><a href="#">Do Not Sell or Share My Info</a></li>
                <li><a href="#">Get Started on Ticketmaster</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-3">Our Network</h4>
              <ul className="space-y-1">
                <li><a href="#">Live Nation</a></li>
                <li><a href="#">House of Blues</a></li>
                <li><a href="#">Front Gate Tickets</a></li>
                <li><a href="#">TicketWeb</a></li>
                <li><a href="#">universe</a></li>
                <li><a href="#">NFL</a></li>
                <li><a href="#">NBA</a></li>
                <li><a href="#">NHL</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-3">About Us</h4>
              <ul className="space-y-1">
                <li><a href="#">Ticketmaster Blog</a></li>
                <li><a href="#">Ticketing Truths</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Ad Choices</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Ticket Your Event</a></li>
                <li><a href="#">Innovation</a></li>
                <li><a href="#">Friends & Partners</a></li>
                <li><a href="#">PayPal</a></li>
                <li><a href="#">Allianz</a></li>
                <li><a href="#">AWS</a></li>
              </ul>
            </div>
          </div>

          <div className="bg-gray-800 py-4 px-6 text-center text-xs text-gray-400">
            <p>By continuing past this page, you agree to our terms of use</p>
            <p className="mt-2 space-x-2">
              <span><a href="#" className="hover:underline">Purchase Policy</a></span>|
              <span><a href="#" className="hover:underline">Privacy Policy</a></span>|
              <span><a href="#" className="hover:underline">Cookie Policy</a></span>|
              <span><a href="#" className="hover:underline">Manage my cookies and ad choices</a></span>
            </p>
            <p className="mt-2">© 1999–2025 Ticketmaster. All rights reserved.</p>
          </div>
        </footer>
      </main>
    </>
  );
}
